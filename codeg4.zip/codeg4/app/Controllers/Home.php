<?php

namespace App\Controllers;

class Home extends BaseController
{

    public function __construct(){
        $this->loginModel=model('loginModel');
    }

    public function index(): string
    {
        return view('pages/home');
    }

    public function loginValidate(){
        $email=$this->request->getPost('email');
        $password=$this->request->getPost('password');
        print_r($this->loginModel->loginCheck($email,$password));
    }
}
