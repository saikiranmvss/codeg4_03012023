<?=$this->extend('layouts/default')?>
<?=$this->section('content')?>

<div class="container-fluid" style="background-color: #ffeaea4a;">
<div class="row login-card">
    <div class="card col-3">
        <div class="card-body">
            <input type="email" placeholder="Email Address" class="form-control" name="email" id="email">
            <div class="invalid-feedback">
                Please provide a valid Email Address.
            </div>
            <br>
            <div class="position-relative">
                <input type="password" placeholder="Password" class="form-control" name="password" id="password">
                <i class="mdi mdi-eye-off pass-eye" onclick="togglePass()"></i>
            </div>            
            <div class="invalid-feedback">
                Please provide a valid Password.
            </div>
            <br>
            <button type="button" class="btn bg-shift w-100" onclick="loginValidate()">Login</button>
        </div>
    </div>
</div>
</div>

<?=$this->endSection()?>