<!-- JAVASCRIPT -->
<script src="<?=base_url()?>public/assets/libs/jquery/jquery.min.js"></script>
<script src="<?=base_url()?>public/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?=base_url()?>public/assets/libs/metismenu/metisMenu.min.js"></script>
<script src="<?=base_url()?>public/assets/libs/simplebar/simplebar.min.js"></script>
<script src="<?=base_url()?>public/assets/libs/node-waves/waves.min.js"></script>
<script src="<?=base_url()?>public/assets/libs/select2/js/select2.min.js"></script>

<script src="<?=base_url()?>public/assets/js/pages/bootstrap-toasts.init.js"></script>

<script src="<?=base_url()?>public/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>public/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

<!-- Required datatable js -->
<script src="<?=base_url()?>public/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>public/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

<!-- Buttons examples -->
<script src="<?=base_url()?>public/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?=base_url()?>public/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<!-- Responsive examples -->
<script src="<?=base_url()?>public/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?=base_url()?>public/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>

<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />

<script src="<?=base_url()?>public/assets/libs/sweetalert2/sweetalert2.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>

    <!-- highletting text js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mark.js/8.11.1/jquery.mark.min.js"></script>

<script src="<?=base_url()?>public/assets/libs/pdfmake/build/pdfmake.min.js"></script>

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.1.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.1.1/js/buttons.print.min.js"></script>
<!-- materialdesign icon js-->
<script src="<?=base_url()?>public/assets/js/pages/materialdesign.init.js"></script>

<script src="<?=base_url()?>public/assets/js/app.js"></script>
<script src="<?=base_url()?>public/assets/js/panel.js"></script>
