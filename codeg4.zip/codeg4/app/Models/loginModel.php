<?php

namespace App\Models;
use CodeIgniter\Model;

class loginModel extends Model{
    public function __construct(){

    }
    public function loginCheck($email,$password){
        $query   = $this->db->query('SELECT * FROM users');
        $results = $query->getResult();
        return $results;
    }
}