function togglePass(){
    if($('#password').attr('type')=='password'){
        $('.pass-eye').addClass('mdi-eye');
        $('.pass-eye').removeClass('mdi-eye-off');
        $('#password').attr('type','text');
    }else{
        $('.pass-eye').removeClass('mdi-eye');
        $('.pass-eye').addClass('mdi-eye-off');
        $('#password').attr('type','password');
    }
}

loginValidate = ()=>{

    let email=$('#email').val();
    let password=$('#password').val();

    if(email=='' || password==''){

        if(email==''){
            $('#email').addClass('is-invalid');
        }else{
            $('#email').addClass('is-valid');
        }

        if(password==''){
            $('#password').addClass('is-invalid');
            $('.pass-eye').css('opacity','0');
        }else{
            $('#password').addClass('is-valid');
            $('.pass-eye').css('opacity','10');
        }


    }

}

$('input').on('focus',function(){
    $(this).removeClass('is-invalid');
    $(this).closest('.invalid-feedback').hide();
})