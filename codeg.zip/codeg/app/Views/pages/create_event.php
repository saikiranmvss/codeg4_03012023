<?=$this->extend('layouts/default')?>
<?=$this->section('content')?>

<div class="container-fluid">
<div class="row login-card">
    <div class="card col-11">
        <div class="card-body">
            <h5 class="text-center">Create Event</h5>
            <form class="">
                <div class="">
                    <label for="event_name">Event Name</label>
                    <input type="text" name="event_name" id="event_name" class="event_name form-control w-25">
                </div>
                <br>
                <div class="">
                    <label for="event_description">Event Description</label>
                    <textarea name="event_description" rows="10" columns="10" id="event_description" class="w-50 event_description form-control"></textarea>
                </div>
                <br>
                <div class="">
                    <label for="event_datetime">Event Date & Time</label>
                    <input type="text" name="event_datetime" id="event_datetime" class="event_datetime form-control" >
                </div>
                <br>
                <div class="">  
                    <button class="btn bg-shift">Submit</button>
                </div>

            </form>
        </div>
    </div>
</div>
</div>

<?=$this->endSection()?>