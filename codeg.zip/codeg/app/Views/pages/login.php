<?=$this->include('includes/head')?>

<div class="container-fluid" style="background-color: #ffeaea4a;">
<div class="row login-card">
    <div class="card col-3">
        <form class="card-body">
            <input type="email" placeholder="Email Address" class="form-control" name="email" id="email">
            <div class="invalid-feedback">
                Please provide a valid Email Address.
            </div>
            <br>
            <div class="position-relative">
                <input type="password" placeholder="Password" class="form-control" name="password" id="password">
                <i class="mdi mdi-eye-off pass-eye" onclick="togglePass()"></i>
                <div class="invalid-feedback">
                    Please provide a valid Password.
                </div>
            </div>            
            <br>
            <button type="button" class="btn bg-shift w-100 login-button" onclick="loginValidate()">Login</button>
            <button class="btn bg-shift w-100 loading-button" style="display:none;" type="button" disabled>
                <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
                Loading...
            </button>
        </form>
    </div>
</div>
</div>
<?=$this->include('includes/footer')?>