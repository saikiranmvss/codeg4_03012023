<?=$this->extend('layouts/default')?>
<?=$this->section('content')?>

<div class="container-fluid">
<div class="row login-card">
    <div class="card col-11">
        <div class="card-body">
            <h5 class="text-center">Events Dashboard</h5>
            <div class="d-flex flex-direction-row justify-content-between">
                <h5 class="card-title">Upcoming Events</h5> 
                <a href="events/create"><button class="btn bg-shift w-20">Create Event</button></a>
            </div>
        </div>
    </div>
</div>
</div>

<?=$this->endSection()?>