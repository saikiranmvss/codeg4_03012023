<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::home');
$routes->get('/login', 'Home::login');
$routes->get('events/create', 'Home::createEvent');
$routes->post('loginValidate','Home::loginValidate');
