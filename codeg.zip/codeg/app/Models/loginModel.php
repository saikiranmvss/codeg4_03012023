<?php

namespace App\Models;
use CodeIgniter\Model;
use Config\Database;
use Config\Session;

class loginModel extends Model{
    public function __construct(){
        $this->db = Database::connect();
    }
    public function loginCheck($email,$password){
        $query = $this->db->table('users')
        ->select('user_id,user_password')
        ->where('user_email',$email)
        ->get();
        
        if($query->getRow()){
            $pass=$query->getRow()->user_password;

            if($pass==$password){

                session()->set('user_id', $query->getRow()->user_password);

                return "0";    
            }else{
                return "1";
            }

        }else{
            return "2";
        }
    }
}


