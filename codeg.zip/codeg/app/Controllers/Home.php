<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function __construct(){
        $this->loginModel=model('loginModel');
    }

    public function login(): string
    {        
        return view('pages/login');
    }

    public function loginValidate(){
        $email=$this->request->getPost('email');
        $password=$this->request->getPost('password');
        return $this->loginModel->loginCheck($email,$password);
    }


    public function home(){    
        if(session('user_id')!=''){    
            return view('pages/home');
        }else{
            return view('pages/login');
        }
    }

    public function createEvent(){
        return view('pages/create_event');
    }
}
