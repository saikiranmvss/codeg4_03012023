function togglePass(){
    if($('#password').attr('type')=='password'){
        $('.pass-eye').addClass('mdi-eye');
        $('.pass-eye').removeClass('mdi-eye-off');
        $('#password').attr('type','text');
    }else{
        $('.pass-eye').removeClass('mdi-eye');
        $('.pass-eye').addClass('mdi-eye-off');
        $('#password').attr('type','password');
    }
}

loginValidate = ()=>{

    $('.login-button').hide();
    $('.loading-button').show();
    let email=$('#email').val();
    let password=$('#password').val();

    if(email=='' || password==''){

        if(email==''){
            $('#email').addClass('is-invalid');
        }else{
            $('#email').addClass('is-valid');
        }

        if(password==''){
            $('#password').addClass('is-invalid');
            $('.pass-eye').css('opacity','0');
        }else{
            $('#password').addClass('is-valid');
            $('.pass-eye').css('opacity','10');
        }

        $('.login-button').show();
        $('.loading-button').hide();

    }else{
        let postData={email,password};
        $.ajax({
            type:'post',
            data:postData,
            url:'loginValidate',
            success:function(data){
                
                if(data==1){
                    $('#password').addClass('is-invalid');
                    $('#email').addClass('is-valid');           
                    
                    $('.login-button').show();
                    $('.loading-button').hide();
                    
                }else if(data==2){
                    $('#email').addClass('is-invalid');
                    $('#password').removeClass('is-invalid');
                    $('#password').parents('.position-relative').closest('.invalid-feedback').hide();

                    $('.login-button').show();
                    $('.loading-button').hide();
                }else{
                    $('#email').addClass('is-valid');
                    $('#password').addClass('is-valid');
                    $('.pass-eye').css('opacity','0');

                    $('.login-button').show();
                    $('.loading-button').hide();

                    location.reload();
                }

            }
        })
    }

}

$('input').on('focus',function(){
    $(this).removeClass('is-invalid');
    $(this).closest('.invalid-feedback').hide();
})